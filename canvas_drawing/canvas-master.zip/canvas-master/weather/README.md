rochester-weather
=================

HTML5 Canvas Visualization of Rochester's Average and Record Temperatures
